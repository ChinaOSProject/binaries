// SPDX-License-Identifier: MIT
#ifndef __DYNAREC_LA_ARCH_H__
#define __DYNAREC_LA_ARCH_H__

#include <stddef.h>
#ifndef BOX64_WINE_UNIX
#include <ucontext.h>
#endif

#include "x64emu.h"
#include "box64context.h"
#include "dynarec_la64_private.h"

// get size of arch specific info (can be 0)
size_t get_size_arch(dynarec_la64_t* dyn);
//populate the array
void* populate_arch(dynarec_la64_t* dyn, void* p, size_t sz);
//adjust flags and more (needed for signal handling)
#ifdef BOX64_WINE_UNIX
void adjust_arch(dynablock_t* db, x64emu_t* emu, CONTEXT* p, uintptr_t x64pc);
#else
void adjust_arch(dynablock_t* db, x64emu_t* emu, ucontext_t* p, uintptr_t x64pc);
#endif
// get if instruction can be regenerated for unaligned access
int arch_unaligned(dynablock_t* db, uintptr_t x64pc);
// get if the native pc is in the native call window of the instruction
int arch_host_call(dynablock_t* db, void* native_pc, uintptr_t x64pc);
#endif // __DYNAREC_LA_ARCH_H__
