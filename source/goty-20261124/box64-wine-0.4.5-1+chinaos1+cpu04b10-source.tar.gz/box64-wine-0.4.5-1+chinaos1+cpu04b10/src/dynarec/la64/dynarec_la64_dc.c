// SPDX-License-Identifier: MIT
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>

#include "debug.h"
#include "box64context.h"
#include "box64cpu.h"
#include "emu/x64emu_private.h"
#include "x64emu.h"
#include "box64stack.h"
#include "callback.h"
#include "emu/x64run_private.h"
#include "x64trace.h"
#include "emu/x87emu_private.h"
#include "dynarec_native.h"

#include "la64_printer.h"
#include "dynarec_la64_private.h"
#include "../dynarec_helper.h"
#include "dynarec_la64_functions.h"


uintptr_t dynarec64_DC(dynarec_la64_t* dyn, uintptr_t addr, uintptr_t ip, int ninst, rex_t rex, int* ok, int* need_epilog)
{
    (void)ip;
    (void)need_epilog;

    uint8_t nextop = F8;
    uint8_t wback;
    uint8_t u8;
    int64_t fixedaddress;
    int unscaled;
    int v1, v2, s1, s2;

    MAYUSE(v2);
    MAYUSE(v1);
    MAYUSE(s1);
    MAYUSE(s2);

    if (MODREG)
        switch (nextop) {
            case 0xC0 ... 0xC7:
                INST_NAME("FADD STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v1);
                        FMOV_S(s2, v2);
                    }
                    FADD_S(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v1);
                        FMOV_D(s2, v2);
                    }
                    FADD_D(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 0xC8 ... 0xCF:
                INST_NAME("FMUL STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v1);
                        FMOV_S(s2, v2);
                    }
                    FMUL_S(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v1);
                        FMOV_D(s2, v2);
                    }
                    FMUL_D(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 0xD0 ... 0xD7:
                INST_NAME("FCOM ST0, STx"); // yep
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v2 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (ST_IS_F(0)) {
                    FCOMS(v1, v2, x1, x2, x3);
                } else {
                    FCOMD(v1, v2, x1, x2, x3);
                }
                break;
            case 0xD8 ... 0xDF:
                INST_NAME("FCOMP ST0, STx");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v2 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (ST_IS_F(0)) {
                    FCOMS(v1, v2, x1, x2, x3);
                } else {
                    FCOMD(v1, v2, x1, x2, x3);
                }
                X87_POP_OR_FAIL(dyn, ninst, x3);
                break;
            case 0xE0 ... 0xE7:
                INST_NAME("FSUBR STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v2);
                        FMOV_S(s2, v1);
                    }
                    FSUB_S(v1, v2, v1);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v2);
                        FMOV_D(s2, v1);
                    }
                    FSUB_D(v1, v2, v1);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 0xE8 ... 0xEF:
                INST_NAME("FSUB STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v1);
                        FMOV_S(s2, v2);
                    }
                    FSUB_S(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v1);
                        FMOV_D(s2, v2);
                    }
                    FSUB_D(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 0xF0 ... 0xF7:
                INST_NAME("FDIVR STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v2);
                        FMOV_S(s2, v1);
                    }
                    FDIV_S(v1, v2, v1);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v2);
                        FMOV_D(s2, v1);
                    }
                    FDIV_D(v1, v2, v1);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 0xF8 ... 0xFF:
                INST_NAME("FDIV STx, ST0");
                v2 = x87_get_st(dyn, ninst, x1, x2, 0, X87_COMBINE(0, nextop & 7));
                v1 = x87_get_st(dyn, ninst, x1, x2, nextop & 7, X87_COMBINE(0, nextop & 7));
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (ST_IS_F(0)) {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_S(s1, v1);
                        FMOV_S(s2, v2);
                    }
                    FDIV_S(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_S(v1, s1, s2);
                    }
                } else {
                    if (!BOX64ENV(dynarec_fastnan)) {
                        s1 = fpu_get_scratch(dyn);
                        s2 = fpu_get_scratch(dyn);
                        FMOV_D(s1, v1);
                        FMOV_D(s2, v2);
                    }
                    FDIV_D(v1, v1, v2);
                    if (!BOX64ENV(dynarec_fastnan)) {
                        X87_ARITH_NAN_FIX_D(v1, s1, s2);
                    }
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            default:
                DEFAULT;
                break;
        }
    else
        switch ((nextop >> 3) & 7) {
            case 0:
                INST_NAME("FADD ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v1);
                    FMOV_D(s2, v2);
                }
                FADD_D(v1, v1, v2);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 1:
                INST_NAME("FMUL ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v1);
                    FMOV_D(s2, v2);
                }
                FMUL_D(v1, v1, v2);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 2:
                INST_NAME("FCOM ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                FCOMD(v1, v2, x1, x6, x3);
                break;
            case 3:
                INST_NAME("FCOMP ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                FCOMD(v1, v2, x1, x6, x3);
                X87_POP_OR_FAIL(dyn, ninst, x3);
                break;
            case 4:
                INST_NAME("FSUB ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v1);
                    FMOV_D(s2, v2);
                }
                FSUB_D(v1, v1, v2);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 5:
                INST_NAME("FSUBR ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v2);
                    FMOV_D(s2, v1);
                }
                FSUB_D(v1, v2, v1);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 6:
                INST_NAME("FDIV ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v1);
                    FMOV_D(s2, v2);
                }
                FDIV_D(v1, v1, v2);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
            case 7:
                INST_NAME("FDIVR ST0, double[ED]");
                v1 = x87_get_st(dyn, ninst, x1, x2, 0, LSX_CACHE_ST_D);
                v2 = fpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, NULL, 1, 0);
                FLD_D(v2, wback, fixedaddress);
                if (!BOX64ENV(dynarec_fastround)) u8 = x87_setround(dyn, ninst, x1, x5);
                if (!BOX64ENV(dynarec_fastnan)) {
                    s1 = fpu_get_scratch(dyn);
                    s2 = fpu_get_scratch(dyn);
                    FMOV_D(s1, v2);
                    FMOV_D(s2, v1);
                }
                FDIV_D(v1, v2, v1);
                if (!BOX64ENV(dynarec_fastnan)) {
                    X87_ARITH_NAN_FIX_D(v1, s1, s2);
                }
                X87_CHECK_PRECISION(v1);
                if (!BOX64ENV(dynarec_fastround)) x87_restoreround(dyn, ninst, u8);
                break;
        }
    return addr;
}
