// SPDX-License-Identifier: MIT
#ifndef __MYSIGNAL_H_
#define __MYSIGNAL_H_

#if !defined(_WIN32) || defined(BOX64_WINE_UNIX)
#include <signal.h>
#else
typedef struct {
    int a;
} sigset_t;

typedef sigset_t __sigset_t;

#define sigfillset(x)

#define SIGILL  4
#define SIGTRAP 5
#define SIGSEGV 11

#undef pthread_sigmask
#define pthread_sigmask(a, b, c) 0
#endif

#endif // __MYSIGNAL_H_
