# Wine 11 corresponding source

This archive accompanies `wine-proton-runtime` and `wine-proton-i386`, version
`11.0-1+chinaos1+goty20261124`, architecture `loongarch64`. The complete
`manifests/payload.json` identifies the two tested debs by SHA-256 and maps every
regular payload member to its build batch, target or source file. The audit
compared all 478 members against the packaged files and frozen inputs, including
file modes. The deb copies used for acceptance had the same whole-file SHA-256.

| Package | Payload files | Batches |
|---|---:|---|
| `wine-proton-runtime` | 312 | 305 handoff07, 2 native loader/server, 1 native OpenGL rebuild, 1 launcher, 3 license documents |
| `wine-proton-i386` | 166 | 158 handoff07, 1 byte-identical guest OpenGL reused by the overlay, 2 guest audio, 2 guest Winsock, 3 license documents |

`base/` is the Wine Git tree at `0fbb98ef4dcc44d035d314557ea9ce530f645fb7`.
`overlays/native/` contains the original frozen handoff07 source snapshot and
patch. The snapshot includes 45 patched tracked files and 13 additional files.
The patch reproduces the 45 tracked paths and the snapshot supplies the other
13. The native OpenGL build has the same changed source as handoff07, and eight
additional directly checked source/header inputs match the base tree. Its
`ntdll.so` and `win32u.so` link inputs are the handoff07 native files. The guest
OpenGL DLL was copied with identical bytes from the guest build.

`overlays/guest/` contains the 12 exact additional guest source-tree files used
for the ordinary i386, audio and Winsock builds. `generation/vulkan/` holds the
two XML registry inputs with their historical hashes. The guest audio objects
are the official `mmdevapi.dll` and `winepulse.drv` PE targets. The latter is the
Windows carrier for a Unix driver, with no exported Windows implementation. The
native Wine package carries the separate Unix code. The Winsock build supplies
`wsock32.dll` and `mswsock.dll`.

`generated-objects/files/` preserves exact observed copies of generated C,
headers, assembler and INF from the five surviving object trees, deduplicated by
SHA-256. `manifests/generated-objects.json` maps paths and build batches to those
copies. These are preserved evidence and optional reference material for the
corresponding tree and configuration. Earlier incremental builds did not
record a separate hash for every WIDL invocation and its outputs. An extant
output alone cannot establish its bytes at every earlier stage. The tree
includes the IDL, original WIDL source and the later native WIDL changes. All
76 runtime NLS files match the tracked `nls/` source-tree resources.

See [BUILD.md](BUILD.md) for source assembly, build and staging. The Wine
launcher and the source patch are original bytes. Build and packaging recipes
use caller-supplied Wine paths. Raw host manifests and the multi-package staging
script remain outside this public archive. The payload scope is limited to
Wine. External Box64, Xlib, compiler/runtime packages and proprietary game
inputs are separate.

## Historical generator inputs

The earlier guest generation record contains SHA-256 fingerprints for two
input files, `dlls/ntdll/ntdll.spec` and `dlls/win32u/win32u.spec`, whose exact old
bytes have not been recovered. The guest compiler consumed `ntsyscalls.h` in
`dlls/ntdll/signal_i386.c` and `win32syscalls.h` in `dlls/win32u/main.c`. Both
headers are included at the precise recorded output hashes. Native
`dlls/ntdll/unix/loader.c` also includes `ntsyscalls.h`. The `.spec` files used by
the build are themselves source inputs to Wine's link and export generation.
The historical guest `ntdll-build-01.log` line 4733 and `prefix-build-01.log`
lines 896 and 8192 pass them from the verified guest source tree. That tree's
`.spec` files and the native snapshot's corresponding files are included. The
missing fingerprints refer to an earlier generation record, with no evidence
that those missing versions were the link inputs. Full hashes for the
historical generator inputs and both recovered build trees are in
`manifests/source-inputs.json`.

The normal build uses the checked-in or overlaid generated files. The Wine
scripts that maintain them are present. A complete replay of every historical
regeneration would require additional registry/data snapshots, separately from
compiling the distributed inputs. `dlls/opengl32/make_opengl` identifies the
pinned GL/WGL and EGL registry revisions. `tools/make_unicode` identifies the
pinned Unicode, locale and codepage data. This source archive was verified
statically. No configure, build, runtime or byte-for-byte rebuild was attempted
for this release preparation.

## Licenses and notices

See `base/LICENSE`, `base/COPYING.LIB`, `base/AUTHORS` and the source-file and
component notices throughout `base/`. `notices/` collects the upstream notices
for the root and ten vendored library directories. Retain the applicable
notices with public distribution, including the Independent JPEG Group
acknowledgment, Unicode data notices, ICC notices and Khronos notices. This
software is based in part on the work of the Independent JPEG Group. The two
observed debs carry the Wine license, LGPL text and authors list. The source
archive carries the component notices as well.
