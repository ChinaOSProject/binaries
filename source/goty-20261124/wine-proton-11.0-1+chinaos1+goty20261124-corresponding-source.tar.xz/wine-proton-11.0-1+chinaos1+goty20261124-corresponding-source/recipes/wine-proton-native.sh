#!/bin/sh
set -eu

runtime=/opt/wine-proton-native
x11=/opt/proton-11.0-2e/runtime
unix=$runtime/lib/wine/loongarch64-unix

export LD_LIBRARY_PATH="$unix:$x11/lib/loongarch64-linux-gnu:/opt/clash-gcc13/lib"
export XLOCALEDIR="$x11/share/X11/locale"
export WINEDLLPATH="$runtime/lib/wine"
export WINESERVER="$runtime/bin/wineserver"
export WINEDLLOVERRIDES='winemenubuilder.exe=d'
export BOX64_NORCFILES=1
export BOX64_DYNAREC=1
export BOX64_DYNAREC_LOG=0
export WINEDEBUG=${WINEDEBUG:--all}
exec "$unix/wine" "$@"
