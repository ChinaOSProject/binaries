#!/bin/sh
set -eu
cd "${GUEST_OBJ:?}"
exec "${RECIPE_DIR:?}/guest-env.sh" "${GUEST_SOURCE:?}/configure" --srcdir=${GUEST_SOURCE:?} \
    --prefix=/opt/wine-proton-guest-pe --enable-win64 --enable-archs=i386 \
    --with-wine-tools=${NATIVE_OBJ:?} --with-mingw=${CLANG21:?}/bin/clang \
    --disable-tests --disable-win16 --without-x --without-freetype CC=gcc CXX=g++ CFLAGS='-O2 -g' CXXFLAGS='-O2 -g'
