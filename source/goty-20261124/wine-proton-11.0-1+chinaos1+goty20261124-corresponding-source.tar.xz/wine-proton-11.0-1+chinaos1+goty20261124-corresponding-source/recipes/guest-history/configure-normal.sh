#!/bin/sh
set -eu
cd "${GUEST_OBJ:?}"
exec "${RECIPE_DIR:?}/guest-env.sh" "${GUEST_SOURCE:?}/configure" --srcdir=${GUEST_SOURCE:?} \
    --prefix=/opt/wine-proton-guest-pe --enable-win64 --enable-archs=i386 \
    --with-wine-tools=${NATIVE_OBJ:?} --with-mingw=${CLANG21:?}/bin/clang \
    --enable-wineboot=i386 --enable-services=i386 --enable-rpcss=i386 --enable-conhost=i386 --enable-winemenubuilder=i386 --enable-plugplay=i386 --enable-spoolsv=i386 --enable-wuauserv=i386 --enable-winex11-drv=i386 --enable-winegstreamer=i386 --enable-wineusb-sys=i386 --enable-winedevice=i386 --enable-wuauserv=i386 --enable-termsv=i386 --enable-winmgmt=i386 \
    --disable-tests --disable-win16 --without-x --without-freetype CC=gcc CXX=g++ CFLAGS='-O2 -g' CXXFLAGS='-O2 -g'
