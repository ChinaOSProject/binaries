#!/usr/bin/env python3
"""Stage the two Wine packages described by the audited manifest."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil


ROOT = Path(__file__).resolve().parent.parent
OBJECTS = {
    'native': 'native-obj', 'guest': 'guest-obj', 'native-opengl': 'native-opengl-obj',
    'guest-audio': 'guest-audio-obj', 'guest-winsock': 'guest-winsock-obj',
}


def digest(path):
    with path.open('rb') as source:
        checksum = hashlib.sha256()
        for block in iter(lambda: source.read(1024 * 1024), b''):
            checksum.update(block)
        return checksum.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build_root', type=Path)
    parser.add_argument('package_root', type=Path)
    parser.add_argument('--verify-original', action='store_true')
    opts = parser.parse_args()
    packages = json.loads((ROOT / 'manifests/payload.json').read_text())
    opts.package_root.mkdir()
    for package in packages:
        name = package['package']
        destination = opts.package_root / name
        size = 0
        for path, row in package['files'].items():
            if 'archive_path' in row:
                source = ROOT / row['archive_path']
            else:
                label = row['object_tree']
                obj_root = opts.build_root / OBJECTS[label]
                if label in ('native', 'guest'):
                    obj_root = Path(os.environ.get(label.upper() + '_OBJ', obj_root))
                source = obj_root / row['make_target']
            target = destination / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            target.chmod(int(row['mode'], 8))
            actual_size = target.stat().st_size
            if opts.verify_original and (actual_size != row['size'] or digest(target) != row['sha256']):
                raise ValueError(f'Payload differs from the original: {name}/{path}')
            size += actual_size
        control = (ROOT / 'recipes' / (name + '.control')).read_text()
        target = destination / 'DEBIAN/control'
        target.parent.mkdir()
        target.write_text(re.sub(r'^Installed-Size: \d+$', f'Installed-Size: {(size + 1023) // 1024}',
                                 control, flags=re.MULTILINE))


if __name__ == '__main__':
    main()
