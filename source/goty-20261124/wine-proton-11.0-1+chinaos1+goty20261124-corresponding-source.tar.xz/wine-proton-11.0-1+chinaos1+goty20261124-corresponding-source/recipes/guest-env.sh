#!/bin/sh
set -eu
export PATH="${CLANG21:?}/bin:$PATH"
export TMPDIR="${GUEST_OBJ:?}/tmp"
export LC_ALL=C
mkdir -p "$TMPDIR"
ulimit -c 0
exec "$@"
