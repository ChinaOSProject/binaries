#!/bin/sh
set -eu
: "${RECIPE_DIR:?}" "${BUILD_ROOT:?}" "${NATIVE_SOURCE:?}" "${GUEST_SOURCE:?}"
: "${NATIVE_OBJ:?}" "${GUEST_OBJ:?}" "${GCC13:?}" "${CLANG21:?}"

goals() {
    phase=$1
    shift
    while IFS= read -r target; do
        set -- "$@" "$target"
    done < "$RECIPE_DIR/targets-$phase.txt"
    make -j2 "$@"
}

native_configure() {
    "$NATIVE_SOURCE/configure" --prefix=/opt/wine-proton-native --enable-win64 --enable-archs= \
        --without-mingw --disable-tests --enable-wow64 --enable-wow64win \
        "CC=$GCC13/bin/gcc -B$BUILD_ROOT/native-bin/" \
        "CXX=$GCC13/bin/g++ -B$BUILD_ROOT/native-bin/" \
        'CFLAGS=-O2 -g' 'CXXFLAGS=-O2 -g' 'LDFLAGS=-Wl,--dynamic-linker=/lib64/ld.so.1' "$@"
}

native_environment() {
    export PATH="$GCC13/bin:${LLVM22:-/opt/llvm22}/bin:$PATH"
    export LD_LIBRARY_PATH="$GCC13/lib:$GCC13/lib64"
    export LIBRARY_PATH="$LD_LIBRARY_PATH"
    export TMPDIR="$BUILD_ROOT/tmp"
    mkdir -p "$TMPDIR" "$BUILD_ROOT/native-bin"
    if [ -n "${LOONG_AS:-}" ]; then
        awk '{ sub("/usr/bin/loongarch64-linux-gnu-as", ENVIRON["LOONG_AS"]); print }' \
            "$RECIPE_DIR/native-bin/as" > "$BUILD_ROOT/native-bin/as"
    else
        cp "$RECIPE_DIR/native-bin/as" "$BUILD_ROOT/native-bin/as"
    fi
    chmod 755 "$BUILD_ROOT/native-bin/as"
}

guest_configure() {
    "$RECIPE_DIR/guest-env.sh" "$GUEST_SOURCE/configure" --srcdir="$GUEST_SOURCE" \
        --prefix=/opt/wine-proton-guest-pe --enable-win64 --enable-archs=i386 \
        --with-wine-tools="$NATIVE_OBJ" --with-mingw="$CLANG21/bin/clang" \
        --disable-tests --disable-win16 --without-x --without-freetype \
        CC=gcc CXX=g++ 'CFLAGS=-O2 -g' 'CXXFLAGS=-O2 -g' "$@"
}

case "$1" in
    native)
        native_environment
        mkdir -p "$NATIVE_OBJ"
        cd "$NATIVE_OBJ"
        native_configure
        make -j2 tools/winegcc/winegcc tools/winebuild/winebuild tools/widl/widl tools/wrc/wrc
        goals native
        ;;
    guest)
        export PATH="$CLANG21/bin:$PATH"
        export LC_ALL=C
        export TMPDIR="$GUEST_OBJ/tmp"
        mkdir -p "$TMPDIR"
        cd "$GUEST_OBJ"
        guest_configure
        make -j2 dlls/ntdll/i386-windows/ntdll.dll dlls/kernelbase/i386-windows/kernelbase.dll \
            dlls/kernel32/i386-windows/kernel32.dll
        "$RECIPE_DIR/guest-history/configure-prefix.sh"
        "$RECIPE_DIR/guest-history/build-prefix.sh"
        "$RECIPE_DIR/guest-history/configure-normal.sh"
        "$RECIPE_DIR/guest-history/build-normal.sh"
        "$RECIPE_DIR/guest-history/build-normal-supplement.sh"
        goals guest -o dlls/ntdll/i386-windows/ntdll.dll -o dlls/kernelbase/i386-windows/kernelbase.dll \
            -o dlls/kernel32/i386-windows/kernel32.dll
        ;;
    guest-audio|guest-winsock)
        phase=$1
        GUEST_OBJ="$BUILD_ROOT/$phase-obj"
        export GUEST_OBJ PATH="$CLANG21/bin:$PATH" TMPDIR="$GUEST_OBJ/tmp" LC_ALL=C
        mkdir -p "$TMPDIR"
        cd "$GUEST_OBJ"
        if [ "$phase" = guest-audio ]; then
            guest_configure --without-pulse --enable-mmdevapi=i386 --enable-winepulse.drv=i386
        else
            guest_configure --without-pulse --enable-wsock32=i386 --enable-mswsock=i386
        fi
        goals "$phase"
        ;;
    native-opengl)
        native_environment
        opengl_obj="$BUILD_ROOT/native-opengl-obj"
        mkdir -p "$opengl_obj"
        cd "$opengl_obj"
        native_configure --with-wine-tools="$NATIVE_OBJ"
        for provider in dlls/ntdll/ntdll.so dlls/win32u/win32u.so; do
            mkdir -p "$(dirname "$provider")"
            cp "$NATIVE_OBJ/$provider" "$provider"
        done
        goals native-opengl --no-print-directory -o dlls/ntdll/ntdll.so -o dlls/win32u/win32u.so
        ;;
    *)
        printf '%s\n' 'Usage: build-wine.sh native|guest|guest-audio|guest-winsock|native-opengl' >&2
        exit 2
        ;;
esac
