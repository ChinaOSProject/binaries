# Wine build and packaging recipe

Run these steps inside a dedicated LoongArch project build container. The
recorded native environment uses a glibc 2.28 base, GCC 13.4, LoongArch GNU
binutils and a `/lib64/ld.so.1` interpreter. The guest build uses Clang/LLVM
21.1.8 targeting `i686-windows`, with distro GCC/G++ for host tools. Install
Make, flex, bison, pkg-config and the host development dependencies for the
features enabled by the native configuration, including the X11 extensions,
OpenGL, FreeType/Fontconfig, GnuTLS, PulseAudio, udev and USB. The historical
native PATH also exposed LLVM 22. Native GCC must use the old LoongArch ABI;
`recipes/native-bin/as` is the original assembler wrapper for that environment.
Point `LOONG_AS` in the adapted recipe at the matching assembler if needed.
Use mount paths without spaces for the compiler driver and Wine tool prefix.

From the extracted archive, create separate source and object directories.
The following overlays already contain generated `configure`, `config.h.in`,
syscall headers and the required Vulkan C/headers/metadata. Retain the tracked
OpenGL C/headers and NLS resources. The ordinary build commands rely on Wine's
Makefile to generate its normal object-directory headers and stubs.

```sh
export RELEASE_ROOT="$PWD"
export RECIPE_DIR="$RELEASE_ROOT/recipes"
export BUILD_ROOT=/work/wine-build
export NATIVE_SOURCE="$BUILD_ROOT/native-src"
export GUEST_SOURCE="$BUILD_ROOT/guest-src"
export NATIVE_OBJ="$BUILD_ROOT/native-obj"
export GUEST_OBJ="$BUILD_ROOT/guest-obj"
export GCC13=/opt/gcc13 CLANG21=/opt/clang21
mkdir -p "$NATIVE_SOURCE" "$GUEST_SOURCE"
cp -a "$RELEASE_ROOT/base/." "$NATIVE_SOURCE/"
cp -a "$RELEASE_ROOT/base/." "$GUEST_SOURCE/"
tar -xzf "$RELEASE_ROOT/overlays/native/checkpoint07-source.tar.gz" -C "$NATIVE_SOURCE"
cp -a "$RELEASE_ROOT/overlays/guest/." "$GUEST_SOURCE/"
```

The native overlay is already patched. To inspect the tracked changes, compare
the supplied patch against the base. Do not apply it a second time.

```sh
"$RECIPE_DIR/build-wine.sh" native
"$RECIPE_DIR/build-wine.sh" guest
"$RECIPE_DIR/build-wine.sh" guest-audio
"$RECIPE_DIR/build-wine.sh" guest-winsock
"$RECIPE_DIR/build-wine.sh" native-opengl
```

In a single shared build tree, the native phase first builds native `winegcc`,
`winebuild`, `widl` and `wrc`, then the payload targets listed in
`recipes/targets-native.txt`. For the normal guest tree, the script builds the
three core targets under the first configuration, then builds the prefix/GUI
and normal closure in the original order. It preserves the core during later
expansion using GNU Make `-o`, as in the recorded build. The guest uses official
Wine i386 COFF import libraries and the native tools from `NATIVE_OBJ`. The guest
OpenGL is supplied by this batch. The audio and Winsock branches configure in
separate object directories with the original explicit enables and compile only
the respective pair of PE targets. The OpenGL branch uses the native source
with its own object directory, copies the native `ntdll.so` and `win32u.so` from
the native object tree and excludes those two dependencies from rebuild with
`-o`. The OpenGL provider hashes observed in the package build were
`9f9b19c55210bb3e49e8b8bc92f666f6e97870aa4f174098c5a3203a2d3698ff` for
`ntdll.so` and `a25cda5c9b1ef5b235b07275cc35a3d420916c0c993521abb95b44f8e214cafa`
for `win32u.so`. For historical comparison the Wine-only scripts and the
native make groups are in `recipes/guest-history/` and
`manifests/native-build-groups.json`.

Use `recipes/stage-wine.py` to stage the two package trees. It derives all copy
paths and permissions from `manifests/payload.json`, copies the exact launcher,
and adjusts the control file's Installed-Size for the selected output. To
replicate the original payload with its original outputs, pass `--verify-original`
for an exact size and SHA-256 check of every input. For ordinary rebuilds
omit this flag because absolute build paths, tool versions and timestamps can
change the binary checksum. Review the license notices and dependency control
before external distribution. The original deb rule used `dpkg-deb --root-owner-group`.

```sh
python3 "$RECIPE_DIR/stage-wine.py" "$BUILD_ROOT" "$BUILD_ROOT/packages"
dpkg-deb --root-owner-group --build "$BUILD_ROOT/packages/wine-proton-runtime"
dpkg-deb --root-owner-group --build "$BUILD_ROOT/packages/wine-proton-i386"
```

These are reconstructed source and build instructions. The preparation did not
rerun them. The archive contains no prebuilt link providers or compiler tools.
