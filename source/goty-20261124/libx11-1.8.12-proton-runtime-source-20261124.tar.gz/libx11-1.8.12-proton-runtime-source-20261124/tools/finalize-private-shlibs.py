from pathlib import Path
import subprocess,json,hashlib
p=Path('/work');j=json.loads((p/'package-manifest.json').read_text())
for row in j['packages']:
 name=row['name']
 if name not in ['libx11-6-proton','libx11-xcb1-proton']:continue
 lib,abi=('libX11','6') if name=='libx11-6-proton' else ('libX11-xcb','1')
 root=p/'packages'/name;(root/'DEBIAN/shlibs').write_text(lib+' '+abi+' '+name+' (>= '+row['version']+')\n')
 deb=Path(row['path']);old=p/'original-control-packages'/deb.name
 before=subprocess.check_output(['ar','p',str(old),'data.tar.xz'])
 subprocess.run(['dpkg-deb','--build','--root-owner-group','-Zxz','-z6',str(root),str(deb)],check=True)
 after=subprocess.check_output(['ar','p',str(deb),'data.tar.xz']);assert before==after
 row.update(sha256=hashlib.sha256(deb.read_bytes()).hexdigest(),bytes=deb.stat().st_size,shlibs=(root/'DEBIAN/shlibs').read_text(),initial_package_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),data_tar_unchanged=True,data_tar_sha256=hashlib.sha256(after).hexdigest())
 print(name,row['sha256'],'data.tar unchanged')
(p/'package-manifest.json').write_text(json.dumps(j,indent=2)+'\n')
