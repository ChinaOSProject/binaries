#!/bin/bash
set -euo pipefail
export LC_ALL=C
export PKG_CONFIG_LIBDIR=/usr/lib/loongarch64-linux-gnu/pkgconfig:/usr/share/pkgconfig
export CC=/usr/bin/gcc
export CFLAGS='-O2 -g -ffile-prefix-map=/src=. -ffile-prefix-map=/work/build=. -fstack-protector-strong -D_FORTIFY_SOURCE=2'
export LDFLAGS='-Wl,--as-needed -Wl,-z,relro -Wl,-z,now -Wl,--no-undefined'
cd /work/build
/src/configure --prefix=/opt/proton-11.0-2e/runtime --libdir=/opt/proton-11.0-2e/runtime/lib/loongarch64-linux-gnu --enable-xthreads --enable-thread-safety-constructor --enable-xlocaledir --disable-specs --without-xmlto --without-fop --without-xsltproc --disable-silent-rules
make -j2 V=1
make -j2 V=1 check
make -j2 V=1 DESTDIR=/work/stage install
