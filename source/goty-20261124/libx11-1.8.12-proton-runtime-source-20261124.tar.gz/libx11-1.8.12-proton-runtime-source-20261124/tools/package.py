import os,sys,json,shutil,hashlib,subprocess
from pathlib import Path
P=Path('/work');STAGE=P/'stage';PREFIX=Path('opt/proton-11.0-2e/runtime');LIB=PREFIX/'lib/loongarch64-linux-gnu'
VERSION='1.8.12-1+chinaos1+proton11.0.2e1';ARCH='loongarch64'
configs={
'libx11-6-proton':('libs',ARCH,'libc6 (>= 2.28), libxcb1 (>= 1.11.1), libx11-data-proton (= '+VERSION+')','X11 client-side library for the private Proton runtime'),
'libx11-xcb1-proton':('libs',ARCH,'libc6 (>= 2.28), libx11-6-proton (= '+VERSION+')','Xlib/XCB interface for the private Proton runtime'),
'libx11-data-proton':('x11','all','','X11 locale and colour data for the private Proton runtime'),
'libx11-dev-proton':('libdevel',ARCH,'libx11-6-proton (= '+VERSION+'), libxau-dev, libxdmcp-dev, x11proto-dev (>= 2018.4), xtrans-dev, libxcb1-dev (>= 1.11.1)','X11 development files for the private Proton runtime'),
'libx11-xcb-dev-proton':('libdevel',ARCH,'libx11-xcb1-proton (= '+VERSION+'), libx11-dev-proton (= '+VERSION+'), libxcb1-dev (>= 1.11.1)','Xlib/XCB development files for the private Proton runtime'),
'libx11-doc-proton':('doc','all','','X11 API manual pages for the private Proton runtime')}
roots={name:P/'packages'/name for name in configs}
for root in roots.values():
 assert not root.exists(),str(root)
 root.mkdir(parents=True)
rows=[];excluded=[]
for source in sorted(STAGE.rglob('*')):
 if not (source.is_file() or source.is_symlink()):continue
 rel=source.relative_to(STAGE);s=str(rel);base=source.name
 if base.endswith('.la'):excluded.append({'path':s,'reason':'Debian rules explicitly removes libtool .la files'});continue
 if rel.parent==LIB:
  if base.startswith('libX11-xcb.so.') :owner='libx11-xcb1-proton'
  elif base.startswith('libX11.so.'):owner='libx11-6-proton'
  elif base in ['libX11.a','libX11.so']:owner='libx11-dev-proton'
  elif base in ['libX11-xcb.a','libX11-xcb.so']:owner='libx11-xcb-dev-proton'
  else:raise RuntimeError('unowned '+s)
 elif '/pkgconfig/' in s:owner='libx11-xcb-dev-proton' if base=='x11-xcb.pc' else 'libx11-dev-proton'
 elif '/include/' in s:owner='libx11-xcb-dev-proton' if base=='Xlib-xcb.h' else 'libx11-dev-proton'
 elif '/share/X11/' in s or '/share/man/man5/' in s:owner='libx11-data-proton'
 elif '/share/man/man3/' in s:owner='libx11-xcb-dev-proton' if base in ['XGetXCBConnection.3','XSetEventQueueOwner.3'] else 'libx11-doc-proton'
 else:raise RuntimeError('unowned '+s)
 dest=roots[owner]/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if source.is_symlink():os.symlink(os.readlink(str(source)),str(dest))
 else:shutil.copy2(str(source),str(dest))
 rows.append({'path':s,'package':owner,'symlink':os.readlink(str(dest)) if dest.is_symlink() else None})
for name in ['libx11-6-proton','libx11-xcb1-proton']:
 for f in (roots[name]/LIB).glob('*.so.*'):
  if not f.is_symlink():subprocess.run(['strip','--strip-unneeded',str(f)],check=True)
packages=[];out=P/'debs';out.mkdir(exist_ok=True)
for name,(section,arch,deps,description) in configs.items():
 root=roots[name];doc=root/PREFIX/'share/doc'/name;doc.mkdir(parents=True)
 shutil.copy2('/tools/debian-copyright',str(doc/'copyright'))
 shutil.copy2('/src/COPYING',str(doc/'COPYING.upstream'))
 (doc/'build-provenance').write_text('Upstream libX11 1.8.12; official tag object b1cf5da316e6465a65503fc54fa95737750f422a; commit 59917d28a3c41ad22d6fc52e323cafe2cdd596d5.\nUnmodified X.org release; GCC8/GLIBC2.28; AI-assisted adaptation and packaging.\nPrivate prefix /opt/proton-11.0-2e/runtime; no system X11 replacement.\n')
 control=root/'DEBIAN';control.mkdir()
 text='Package: '+name+'\nVersion: '+VERSION+'\nArchitecture: '+arch+'\nSection: '+section+'\nPriority: optional\nMaintainer: ChinaOSProject <chinaosproject@users.noreply.github.com>\nHomepage: https://gitlab.freedesktop.org/xorg/lib/libx11\n'
 if deps:text+='Depends: '+deps+'\n'
 if arch=='all':text+='Multi-Arch: foreign\n'
 text+='Installed-Size: '+str((sum(f.stat().st_size for f in root.rglob('*') if f.is_file() and not f.is_symlink())+1023)//1024)+'\nDescription: '+description+'\n Built from the pinned unmodified X.org release for an isolated Proton prefix.\n'
 (control/'control').write_text(text)
 if name in ['libx11-6-proton','libx11-xcb1-proton']:
  library,abi=('libX11','6') if name=='libx11-6-proton' else ('libX11-xcb','1')
  (control/'shlibs').write_text(library+' '+abi+' '+name+' (>= '+VERSION+')\n')
 md5=[]
 for f in sorted(root.rglob('*')):
  if f.is_file() and not f.is_symlink() and 'DEBIAN' not in f.relative_to(root).parts:
   md5.append(hashlib.md5(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(root)))
 (control/'md5sums').write_text('\n'.join(md5)+'\n')
 path=out/(name+'_v'+VERSION+'_'+arch+'.deb')
 subprocess.run(['dpkg-deb','--build','--root-owner-group','-Zxz','-z6',str(root),str(path)],check=True)
 packages.append({'name':name,'version':VERSION,'architecture':arch,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'depends':deps,'control':text})
for row in rows:
 f=roots[row['package']]/row['path']
 if not f.is_symlink():row.update(sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size)
(P/'package-manifest.json').write_text(json.dumps({'packages':packages,'ownership':rows,'excluded':excluded},indent=2)+'\n')
print(json.dumps(packages,indent=2))
