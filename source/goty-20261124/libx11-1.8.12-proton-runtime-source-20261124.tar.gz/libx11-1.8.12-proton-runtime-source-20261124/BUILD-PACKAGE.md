# Build and packaging procedure

## Build inputs

Use the bundled, signed X.Org release archive. Its generated `configure` permits the build without regenerating Autotools inputs. The upstream `master` history contains the fixed tag. The original local `debian10` and `loong64` branches both pointed at the tag commit. The upstream converter locking commit `b52ba5c209165fc2c533b77b86147b31763299f3` is in that release's ancestry. The original build applied zero upstream source patches and zero Debian source patches.

The original build ran natively in a dedicated, offline Loongnix GNU/Linux 20 (Debian 10 era) Podman image. The imported root filesystem archive had SHA-256 `8160ce74c14260ecb728ae64ff8ff3bbc26a497d01d396d4f736cec5bbd4242a`. This is a provenance identifier. Supply a suitable old-ABI Loongnix image locally when using this recipe.

| Original environment | Version or value |
| --- | --- |
| Debian architecture / library triplet | `loongarch64` / `loongarch64-linux-gnu` |
| GNU libc | `2.28-10.lnd.38` |
| GCC | `8.3.0-6.lnd.vec.44` |
| GNU binutils | `2.31.1-23.lnd.vec.1` |
| `libxcb1`, `libxcb1-dev` | `1.13.1-2.1` |
| `x11proto-dev`, `xtrans-dev` | `2018.4-4.1`, `1.3.5-1.1` |
| `libxau6`, `libxdmcp6` | `1:1.0.8-1.1`, `1:1.1.2-3.1` |
| `pkg-config` modules `xproto`, `xextproto`, `xtrans`, `xcb` | `7.0.32`, `7.3.0`, `1.3.5`, `1.13.1` |

The image needs the above development inputs, libc headers, GCC/binutils, Make, `pkg-config`, Perl for the compose check, Python 3 for packaging and `dpkg-deb` with xz and `--root-owner-group` support. The image's normal system `pkgconfig` locations are set explicitly in `tools/build.sh`. The original build generated no additional compiler, toolchain or dependency packages.

## Build and stage

The archived `tools/build.sh` is the original script. It uses `/usr/bin/gcc`, `LC_ALL=C`, `-O2 -g`, stack protection, `FORTIFY_SOURCE=2`, and debug prefix maps for `/src` and `/work/build`. Link flags enable `--as-needed`, `relro`, `now` and `--no-undefined`. The script enables Xlib threading, its thread-safety constructor and `XLOCALEDIR`, and disables spec generation and the XML/FO documentation tools. It runs `configure`, `make -j2 V=1`, `make -j2 V=1 check`, and `make -j2 V=1 DESTDIR=/work/stage install`. The prefix is `/opt/proton-11.0-2e/runtime` and the library directory is `lib/loongarch64-linux-gnu` below it.

For a future build, the following example mounts the extracted source at `/src`, the scripts and Debian copyright input at `/tools`, and an empty workspace at `/work`. Run the example from the extracted bundle directory with `BUILD_IMAGE` set to the local image tag or ID.

```sh
set -eu
bundle=$(pwd -P)
: "${BUILD_IMAGE:?set BUILD_IMAGE to a local Loongnix image}"
workspace=$(mktemp -d)
mkdir -p "$workspace/build" "$workspace/tmp"
tar -xJf "$bundle/upstream/libX11-1.8.12.tar.xz" -C "$workspace"

podman run --rm --pull=never --network=none --arch loongarch64 \
  --cap-drop=all --security-opt=no-new-privileges \
  --security-opt=seccomp=unconfined \
  --volume "$workspace/libX11-1.8.12:/src:ro" \
  --volume "$workspace:/work:rw" \
  --volume "$bundle/tools:/tools:ro" \
  --env TMPDIR=/work/tmp --env DISPLAY= \
  --env PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  "$BUILD_IMAGE" /bin/bash -c \
  '/bin/bash /tools/build.sh && python3 /tools/package.py'
```

The `seccomp` setting matches the original LoongArch build environment. The script stages files in the workspace and writes packages to its `debs/` subdirectory. The recipe preserves the original source and packaging logic. A byte-identical `.deb` rebuild was not established. The original build did not pin package timestamps with `SOURCE_DATE_EPOCH`. Compare fresh results to the original hashes in `runtime-package-audit.json`.

## Split and package

The reference is Debian trixie source package `libx11` version `2:1.8.12-1`, using its control, install lists, rules and copyright. The private package names have their own version sequence. All runtime payload paths are under the Proton prefix. The emitted packages declare their dependencies directly and carry no `Provides`, `Conflicts` or `Replaces` against system libX11.

| Runtime package | Stage contents and final dependencies |
| --- | --- |
| `libx11-6-proton` | `libX11.so.6.4.0` with relative symlink `libX11.so.6`. Depends on `libc6 (>= 2.28)`, `libxcb1 (>= 1.11.1)` and matching `libx11-data-proton`. |
| `libx11-xcb1-proton` | `libX11-xcb.so.1.0.0` with relative symlink `libX11-xcb.so.1`. Depends on `libc6 (>= 2.28)` and matching `libx11-6-proton`. |
| `libx11-data-proton` | 189 locale files, `XErrorDB`, `Xcms.txt` and two section 5 man pages. Architecture `all`, `Multi-Arch: foreign`, no package dependencies. |

The exact archived `tools/package.py` also emits the development and documentation siblings from the same staged tree. It drops the two `.la` files, preserves relative symlinks, runs `strip --strip-unneeded` on the two real shared objects, and installs the notices from `/src/COPYING` and `/tools/debian-copyright` with a short build provenance note in each package. It generates `DEBIAN/control`, the payload `md5sums` and private provider mappings in `DEBIAN/shlibs` for the two shared libraries. `dpkg-deb --build --root-owner-group -Zxz -z6` produces the binary packages.

The historical initial library packages had no private `shlibs` entries. The bundled `tools/finalize-private-shlibs.py` records the follow-up packaging step. It used the original packages in `/work/original-control-packages/` to assert byte equality of compressed `data.tar.xz` before and after adding the mappings. The archived `tools/package.py` already writes the final mappings, so the documented fresh-build command only invokes it once.

Debian packaging references:

- https://deb.debian.org/debian/pool/main/libx/libx11/libx11_1.8.12-1.dsc
- https://deb.debian.org/debian/pool/main/libx/libx11/libx11_1.8.12-1.diff.gz
- https://salsa.debian.org/xorg-team/lib/libx11.git

The archived Debian source diff had SHA-256 `2231b0ec8ce2eb380256b67eb30c05d90b0e92d75dd583c24e0bf640b3078977` and matched its `.dsc`.

## Original verification

The original `make check` passed `compose-check.pl` (1/1). A separate container installed the original six-package set, passed package checks, and ran a no-display consumer with `XInitThreads` and locale conversion. The two-thread converter probe completed 160,000 conversions with zero failures. The package control update described above preserved the two tested library payloads byte for byte.

Both runtime libraries have ELF machine `258`, flags `0x3`, and no `RPATH` or `RUNPATH`. Their original recursive closure required GLIBC 2.28 or earlier. Static analysis confirmed `_conv_lock` initialization and its use around converter lookup and registration. These checks cover the Xlib candidate in isolation. Wine GUI behavior and the cause of an earlier application hang remain outside these results.
